package com.fms.repo;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;

import com.fms.model.Question;

import reactor.core.publisher.Mono;

@Repository
public interface QuestionRepository extends ReactiveCrudRepository<Question, Integer> {


	/*@Query("insert into Question values(?)")
	void save(Mono<Question> qn);*/

	

}
