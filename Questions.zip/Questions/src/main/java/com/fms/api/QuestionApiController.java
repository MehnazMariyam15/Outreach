package com.fms.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fms.model.Question;
import com.fms.repo.QuestionRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Optional;
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2020-02-03T11:07:12.473+05:30[Asia/Calcutta]")
@RestController
public class QuestionApiController implements QuestionApi {
	
	
 
	
	@Autowired
	QuestionRepository questionRepository;
	
	@GetMapping("/question")
	public Flux<Question> getAllQuestions() {
		System.out.println("--------------------------------------------------------------");
		return questionRepository.findAll();
	}
	
	@PostMapping("/add")
//	@ResponseBody
	public Mono<Question> addQuestions(@RequestBody Question qn){
		System.out.println(qn);
		 return questionRepository.save(qn);
	}
 
    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public QuestionApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    @Override
    public Optional<ObjectMapper> getObjectMapper() {
        return Optional.ofNullable(objectMapper);
    }

    @Override
    public Optional<HttpServletRequest> getRequest() {
        return Optional.ofNullable(request);
    }
    
    @GetMapping("/hi")
	public String sayHi() {
		System.out.println("--------------------------------------------------------------");
		return "HIIIIIIIIIIIII";
	}
}
